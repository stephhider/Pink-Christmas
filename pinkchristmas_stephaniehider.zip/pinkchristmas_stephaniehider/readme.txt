Pink Christmas
by Stephanie Hider
http://stephaniehider.com and twitter.com/stephhider


Thank you for the tweet!

These are for you to have to do with however you like under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/

Use them in your Christmas cards, on your websites, and wherever else both personal and commercial. Cheers. Attribution is appreciated but not required, you can not sell or act like you made them, of course. If you think of it, it would be fun if you share these, and let me know where you use them.